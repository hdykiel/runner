marathoner <-
function(minutes = 185, weeks = 26){
  
  # include error if minutes is not numeric
  if(!is.numeric(minutes)){
    stop("minutes argument must be numeric")
  } else if(minutes != 185){
    stop("A training plan only exists for a 3:05 marathon at this time. Please update your selection to 185 minutes. ")
  }
  
  # training plan for 3:05 marathon
  if(minutes == 185){
    df <- tibble(
      week = rep(1:weeks, each = 3),
      day = rep(c("Monday", "Wednesday", "Weekend"), weeks),
      run = rep(c("Sprints", "Pace Run", "Long Run"), weeks),
      sprints.number = NA
    )
    
    # set maximum number of sprints
    max_sprint <- 8
    
    # calculate number of sprints + pace
    df <- df %>% 
      mutate(sprints.number = ifelse(week <= 5 & run == "Sprints", week + 2, ifelse(run == "Sprints", 8, NA)),
             pace = ifelse(run == "Pace Run", "6:40", ifelse(run == "Sprints", "6:00", "easy run")))
  
    print(df)
  }
  
}
